/*
 *  Created on: Dec 22, 2020
 *      Author: kompalli
 */
#include "BitVector.h"


int BitVector::readNextItemFromFile(FILE* inputFileStream)
{
   if (! inputFileStream)
   {
       char* message = new char[2048];
       sprintf(message, "Cannot open input file for reading");
       throw std::ios_base::failure(message);
       delete []message;
   }
   std::string readInputs;
   long int returnInteger;
   char inputs[20];
   char* inputsRead = std::fgets(inputs, sizeof inputs, inputFileStream);

   int z = 0;
   for (int i = 0; i < sizeof(inputs); i++)
   {

       if((inputs[i] == ' ' && z != 0 && inputs[i+1] !=(char)0 && inputs[i+1] != '\t' && inputs[i+1] != ' ' && inputs[i+1] != '\n')||(inputs[i] == '\n' && z != 0 && inputs[i+1] !=(char)0 && inputs[i+1] != '\t' && inputs[i+1] != ' ' && inputs[i+1] != '\n')||(inputs[i] == '\t' && z != 0 && inputs[i+1] !=(char)0 && inputs[i+1] != '\t' && inputs[i+1] != ' ' && inputs[i+1] != '\n') || (inputs[i] == '.')||(inputs[i] >= 'A' && inputs[i] <= 'z'))
       {
           readInputs = "";
           break;
       }

       else if((inputs[i] == '\t')||(inputs[i] == ' ')||(inputs[i] == '\n'))
           continue;
       if (inputs[i] == (char)0)
           break;
       z = z + 1;
       readInputs.push_back(inputs[i]);
   }

   if(readInputs != "")
   {
       sscanf(readInputs.c_str(), "%ld", &returnInteger);
       if(returnInteger>INT_MAX || returnInteger < INT_MIN)
    	   returnInteger = readNextItemFromFile(inputFileStream);
   }
   else
   {
       if(inputsRead == NULL)
       {
           throw std::invalid_argument("End of File");
       }
       else
       {
           returnInteger = readNextItemFromFile(inputFileStream);
       }
   }
   return returnInteger;
}

int BitVector::testWithFile(char *inputFilePath, char *outputFilePath){
	FILE* inFileStream = fopen(inputFilePath, "r");
	if (! inFileStream){
		char* message = new char[2048];
		sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
		throw std::ios_base::failure(message);
		delete []message;
	}

	FILE* outFileStream = fopen(outputFilePath, "w");
	if (! outFileStream){
		char* message = new char[2048];
		sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
		throw std::ios_base::failure(message);
		delete []message;
	}

	LogManager::writePrintfToLog(LogManager::Level::Status, "UniqueInt::processFile", "Starting the processing");

	fflush(outFileStream);
	fclose(outFileStream);
	fclose(inFileStream);
}

int BitVector::generateTestCases(char* outputFilePath, int min, int max, int numberOfEntries, int errorTypes){
	if (false)
		return 0;
	FILE* outFileStream = fopen(outputFilePath, "w");
	if (! outFileStream){
		char* message = new char[2048];
		sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
		throw std::ios_base::failure(message);
		delete []message;
	}
	int currInt;
	int maxRandomToAddError = 5;
	for (int i=0; i< numberOfEntries; i++){
		currInt = getRandomInt(min, max);
		if (errorTypes == 0){
			fprintf(outFileStream, "%d\n", currInt);
		}
		if (errorTypes == 1){
			if (getRandomInt(0, maxRandomToAddError) == 3){
				int intNum = getRandomInt(0, maxRandomToAddError);
				float floatNum = ((float) intNum) / 100;
				fprintf(outFileStream, "%f\n", floatNum);
			}
			if (getRandomInt(0, maxRandomToAddError) == 2)
				fprintf(outFileStream, "%c", generateRandomWhiteSpace());
			fprintf(outFileStream, "%d\n", currInt);
		}

		if (errorTypes == 2){
			if (getRandomInt(0, maxRandomToAddError) == 2)
				fprintf(outFileStream, "%c\n", generateRandomWhiteSpace());
			fprintf(outFileStream, "%d\n", currInt);
		}

		if (errorTypes == 3){
			if (getRandomInt(0, maxRandomToAddError) == 2){
				std::string randomStr = genRandomString(3);
				fprintf(outFileStream, "%s\n", randomStr.c_str());
			}
			fprintf(outFileStream, "%d\n", currInt);
		}
	}
	fflush(outFileStream);
	fclose(outFileStream);
}
int BitVector::generateTestCases(char* outputFolderPath){
	char filePath[1024];
	int numElements;
	int minValue[2] = {-1023, INT_MIN};
	int maxValue[2] = {1023, INT_MAX};
	char dataType[2][5] = {"easy", "hard"};

	for (int k=0; k<2; k++){
		for (int i=0; i<4; i++){
			sprintf(filePath, "%s/%s_sample_0%d.txt", outputFolderPath, dataType[k], i+1);
			numElements = getRandomInt(500000, 800000);
			LogManager::writePrintfToLog(LogManager::Level::Status, "UniqueInt::generateTestCases",
					"numElements=%d", numElements);
			generateTestCases(filePath, minValue[k], maxValue[k], numElements, i);

			sprintf(filePath, "%s/%s_test_0%d.txt", outputFolderPath, dataType[k], i+1);
			numElements = getRandomInt(500000, 800000);
			LogManager::writePrintfToLog(LogManager::Level::Status, "UniqueInt::generateTestCases",
					"numElements=%d", numElements);
			generateTestCases(filePath, minValue[k], maxValue[k], numElements, i);
		}
	}
}

int BitVector::processFile(char *inputFilePath, char *outputFilePath)

{

	FILE* inFileStream = fopen(inputFilePath, "r");
		if (! inFileStream){
			char* message = new char[2048];
			sprintf(message, "Cannot open input file for reading: %s", inputFilePath);
			throw std::ios_base::failure(message);
			delete []message;
		}

		FILE* outFileStream = fopen(outputFilePath, "w");
		if (! outFileStream){
			char* message = new char[2048];
			sprintf(message, "Cannot open output file for writing: %s", outputFilePath);
			throw std::ios_base::failure(message);
			delete []message;
		}

 BitArray **currentArray = new BitArray*[41944];

  for (unsigned short i = 0; i < 41944; i++)

      currentArray[i] = NULL;
   int index;
  int number;
  char n[10];
  try {
      while (!feof(inFileStream))
      {
          number = readNextItemFromFile(inFileStream);
index = floor(( number - (-2147483648)) / 102400);
  if (currentArray[index] == NULL)
           {
              currentArray[index] = new BitArray(102400);
              currentArray[index]->setBit(number - (-2147483648 +(102400 * index)), true);
               sprintf(n, "%d\n", 1);
               fputs(n, outFileStream);
          }
          else
          {
              if (currentArray[index]->getBit(number - (-2147483648 +(102400 * index))) == true)
              {
                   sprintf(n, "%d\n", 0);
                   fputs(n, outFileStream);
              }
              else
              {
                  currentArray[index]->setBit(number - (-2147483648 +(102400 * index)), true);
                  sprintf(n, "%d\n", 1);
                  fputs(n, outFileStream);
              }
          }
      }
  }
  catch(std::invalid_argument& e)
  {
	   if (strcmp(e.what(), "EoF reached") == 0)
	       {
	           LogManager::writePrintfToLog(LogManager::Level::Status,
	                           "UniqueInt::processFile",
	                           "OK to continue");
	       }
	       else
	       {
	           return -1;
	       }
  }

  fflush(outFileStream);
  fclose(outFileStream);
  fclose(inFileStream);
}

